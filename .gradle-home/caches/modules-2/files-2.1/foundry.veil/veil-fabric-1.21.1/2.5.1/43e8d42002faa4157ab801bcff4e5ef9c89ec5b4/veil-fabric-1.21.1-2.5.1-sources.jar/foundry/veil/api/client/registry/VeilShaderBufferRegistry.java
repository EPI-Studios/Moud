package foundry.veil.api.client.registry;

import foundry.veil.Veil;
import foundry.veil.api.client.render.CameraMatrices;
import foundry.veil.api.client.render.GuiInfo;
import foundry.veil.api.client.render.VeilShaderBufferLayout;
import foundry.veil.platform.registry.RegistrationProvider;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

/**
 * Registry for custom shader buffers created with {@link VeilShaderBufferLayout#builder()}.
 */
public final class VeilShaderBufferRegistry {

    public static final class_5321<class_2378<VeilShaderBufferLayout<?>>> REGISTRY_KEY = class_5321.method_29180(Veil.veilPath("shader_buffer"));
    private static final RegistrationProvider<VeilShaderBufferLayout<?>> PROVIDER = RegistrationProvider.get(REGISTRY_KEY, Veil.MODID);
    public static final class_2378<VeilShaderBufferLayout<?>> REGISTRY = PROVIDER.asVanillaRegistry();

    public static final Supplier<VeilShaderBufferLayout<CameraMatrices>> CAMERA = register("camera", CameraMatrices::createLayout);
    public static final Supplier<VeilShaderBufferLayout<GuiInfo>> GUI_INFO = register("gui_info", GuiInfo::createLayout);

    private VeilShaderBufferRegistry() {
    }

    @ApiStatus.Internal
    public static void bootstrap() {
    }

    private static <T> Supplier<VeilShaderBufferLayout<T>> register(String name, Supplier<VeilShaderBufferLayout<T>> layout) {
        return PROVIDER.register(name, layout);
    }
}
