package foundry.veil.api.client.render.rendertype;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import foundry.veil.Veil;
import foundry.veil.api.client.render.VeilRenderBridge;
import foundry.veil.api.client.render.VeilRenderSystem;
import foundry.veil.api.client.render.vertex.VeilVertexFormat;
import foundry.veil.api.event.VeilRegisterFixedBuffersEvent;
import foundry.veil.impl.client.render.pipeline.CullFaceShard;
import foundry.veil.mixin.rendertype.accessor.RenderStateShardAccessor;
import foundry.veil.mixin.rendertype.accessor.RenderTypeAccessor;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_286;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_5944;
import net.minecraft.class_9801;

import static org.lwjgl.opengl.GL11C.*;

/**
 * Custom Veil-implemented render types.
 */
public final class VeilRenderType extends class_1921 {

    public static final class_4668.class_4672 NEVER_DEPTH_TEST = new class_4668.class_4672("never", GL_NEVER);
    public static final class_4668.class_4672 LESS_DEPTH_TEST = new class_4668.class_4672("<", GL_LESS);
    public static final class_4668.class_4672 NOTEQUAL_DEPTH_TEST = new class_4668.class_4672("<", GL_NOTEQUAL);
    public static final class_4668.class_4672 GEQUAL_DEPTH_TEST = new class_4668.class_4672(">=", GL_GEQUAL);

    public static final class_4668 CULL_FRONT = new CullFaceShard(GL_FRONT);
    public static final class_4668 CULL_BACK = new CullFaceShard(GL_BACK);
    public static final class_4668 CULL_FRONT_AND_BACK = new CullFaceShard(GL_FRONT_AND_BACK);
    public static final class_4668.class_4686 NO_WRITE = new class_4668.class_4686(false, false);

    private static final EnumMap<GlStateManager.class_1030, class_8559> COLOR_LOGIC_SHARDS = new EnumMap<>(GlStateManager.class_1030.class);

    static {
        for (GlStateManager.class_1030 logicOp : GlStateManager.class_1030.values()) {
            COLOR_LOGIC_SHARDS.put(logicOp, new class_8559(logicOp.name().toLowerCase(Locale.ROOT), () -> {
                RenderSystem.enableColorLogicOp();
                RenderSystem.logicOp(logicOp);
            }, RenderSystem::disableColorLogicOp));
        }
    }

    private static final class_5942 PARTICLE = VeilRenderBridge.shaderState(Veil.veilPath("quasar/particle"));
    private static final class_5942 PARTICLE_ADDITIVE = VeilRenderBridge.shaderState(Veil.veilPath("quasar/particle_additive"));

    private static final BiFunction<class_2960, Boolean, class_1921> QUASAR_PARTICLE = class_156.method_34865((texture, additive) -> {
        class_4688 state = class_1921.class_4688.method_23598()
                .method_34578(additive ? PARTICLE_ADDITIVE : PARTICLE)
                .method_34577(new class_4683(texture, false, false))
                .method_23615(additive ? field_21366 : field_21370)
                .method_23608(field_21383)
                .method_23616(field_21350)
                .method_23617(false);
        return method_24049(Veil.MODID + ":quasar_particle", VeilVertexFormat.QUASAR_PARTICLE, class_293.class_5596.field_27382, field_32774, false, !additive, state);
    });
    private static final Function<class_2960, class_1921> QUASAR_TRAIL = class_156.method_34866((texture) -> {
        class_4688 state = class_4688.method_23598()
                .method_34578(field_38344)
                .method_34577(new class_4683(texture, false, false))
                .method_23615(field_21366)
                .method_23616(field_21350)
                .method_23603(field_21345)
                .method_23617(false);
        return class_1921.method_24049(Veil.MODID + ":quasar_trail", class_290.field_1580, class_293.class_5596.field_27380, field_32775, false, false, state);
    });

    public static class_1921 quasarParticle(class_2960 texture, boolean additive) {
        return QUASAR_PARTICLE.apply(texture, additive);
    }

    public static class_1921 quasarTrail(class_2960 texture) {
        return QUASAR_TRAIL.apply(texture);
    }

    public static class_4685 noTransparencyShard() {
        return class_4668.field_21364;
    }

    public static class_4685 additiveTransparencyShard() {
        return class_4668.field_21366;
    }

    public static class_4685 lightningTransparencyShard() {
        return class_4668.field_21367;
    }

    public static class_4685 glintTransparencyShard() {
        return class_4668.field_21368;
    }

    public static class_4685 crumblingTransparencyShard() {
        return class_4668.field_21369;
    }

    public static class_4685 translucentTransparencyShard() {
        return class_4668.field_21370;
    }

    public static class_4672 noDepthTestShard() {
        return class_4668.field_21346;
    }

    public static class_4672 equalDepthTestShard() {
        return class_4668.field_21347;
    }

    public static class_4672 lequalDepthTestShard() {
        return class_4668.field_21348;
    }

    public static class_4672 greaterDepthTestShard() {
        return class_4668.field_44814;
    }

    public static class_4671 cullShard() {
        return class_4668.field_21344;
    }

    public static class_4671 noCullShard() {
        return class_4668.field_21345;
    }

    public static class_4676 lightmap() {
        return class_4668.field_21383;
    }

    public static class_4676 noLightmap() {
        return class_4668.field_21384;
    }

    public static class_4679 overlay() {
        return class_4668.field_21385;
    }

    public static class_4679 noOverlay() {
        return class_4668.field_21386;
    }

    public static class_4675 noLayering() {
        return class_4668.field_21352;
    }

    public static class_4675 polygonOffsetLayering() {
        return class_4668.field_21353;
    }

    public static class_4675 viewOffsetLayering() {
        return class_4668.field_22241;
    }

    public static class_4686 colorDepthWriteShard() {
        return class_4668.field_21349;
    }

    public static class_4686 colorWriteShard() {
        return class_4668.field_21350;
    }

    public static class_4686 depthWriteShard() {
        return class_4668.field_21351;
    }

    public static class_8559 colorLogicStateShard(GlStateManager.class_1030 op) {
        return COLOR_LOGIC_SHARDS.get(op);
    }

    /**
     * Retrieves and caches a render type with the specified id.
     *
     * @param id     The id of the render type to get
     * @param params Additional parameters to configure the render type
     * @return The render type created or <code>null</code> if unregistered or an error occurs
     */
    public static @Nullable class_1921 get(class_2960 id, Object... params) {
        return VeilRenderSystem.renderer().getDynamicRenderTypeManager().get(id, params);
    }

    /**
     * Creates a new wrapper pointing to a.
     *
     * @param id The id of the render type to wrap
     * @return A wrapper render type that points to the specified dynamic render type
     * @since 2.0.0
     */
    @Contract(value = "_->new", pure = true)
    public static RenderTypeWrapper getWrapper(class_2960 id) {
        return new RenderTypeWrapper(id);
    }

    /**
     * Retrieves the name of the specified render shard.
     *
     * @param shard The render shard to get the name of
     * @return The name of the render type to get
     */
    public static String getName(class_4668 shard) {
        return ((RenderStateShardAccessor) shard).getName();
    }

    public static VeilRenderTypeAccessor getShards(class_1921 renderType) {
        if (!(renderType instanceof class_4687 compositeRenderType)) {
            throw new IllegalArgumentException("Expected composite render type to be an instance of " + class_4687.class.getName() + ", but was " + renderType.getClass());
        }
        return (VeilRenderTypeAccessor) (Object) compositeRenderType.method_35784();
    }

    /**
     * Creates a render type that uses a single draw buffer, but re-uses the data to draw the specified layers.
     *
     * @param layers The layers to use
     * @return A render type that draws all layers from a single buffer
     * @throws IllegalStateException If there are zero layers, the vertex formats don't all match, or the primitive modes don't match
     */
    public static class_1921 layered(class_1921... layers) {
        if (layers.length == 0) {
            throw new IllegalArgumentException("At least 1 render type must be specified");
        }
        if (layers.length == 1) {
            return layers[0];
        }
        ImmutableList.Builder<class_1921> builder = ImmutableList.builder();
        class_293 format = layers[0].method_23031();
        class_293.class_5596 mode = layers[0].method_23033();
        int bufferSize = layers[0].method_22722();
        boolean sortOnUpload = ((RenderTypeAccessor) layers[0]).isSortOnUpload();
        for (int i = 1; i < layers.length; i++) {
            class_1921 layer = layers[i];
            if (!layer.method_23031().equals(format)) {
                throw new IllegalArgumentException("Expected " + layer + " to use " + format + ", but was " + layer.method_23031());
            }
            if (!layer.method_23033().equals(mode)) {
                throw new IllegalArgumentException("Expected " + layer + " to use " + mode + ", but was " + layer.method_23033());
            }
            bufferSize = Math.max(bufferSize, layer.method_22722());
            if (((RenderTypeAccessor) layer).
                    isSortOnUpload()) {
                sortOnUpload = true;
            }
            builder.add(layer);
        }
        return new LayeredRenderType(layers[0], builder.build(), "LayeredRenderType[" + Arrays.stream(layers).map(VeilRenderType::getName).collect(Collectors.joining(", ")) + "]", bufferSize, sortOnUpload);
    }

    private VeilRenderType(String $$0, class_293 $$1, class_293.class_5596 $$2, int $$3, boolean $$4, boolean $$5, Runnable $$6, Runnable $$7) {
        super($$0, $$1, $$2, $$3, $$4, $$5, $$6, $$7);
    }

    /**
     * Layers multiple render types on top of each other to re-use the same mesh data when rendering.
     * <br>
     * Essentially, this acts as "render passes" for a render type.
     */
    public static class LayeredRenderType extends class_1921 {

        private final List<class_1921> layers;

        private LayeredRenderType(class_1921 defaultValue, List<class_1921> layers, String name, int bufferSize, boolean sortOnUpload) {
            super(name, defaultValue.method_23031(), defaultValue.method_23033(), bufferSize, defaultValue.method_23037(), sortOnUpload, defaultValue::method_23516, defaultValue::method_23518);
            this.layers = layers;
        }

        @Override
        public void method_60895(@NotNull class_9801 meshData) {
            super.method_60895(meshData);
            if (class_286.field_38982 != null) {
                class_5944 shader = RenderSystem.getShader();
                if (shader == null) {
                    return;
                }

                Matrix4f modelViewMatrix = RenderSystem.getModelViewMatrix();
                Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
                for (class_1921 layer : this.layers) {
                    layer.method_23516();
                    class_286.field_38982.method_34427(modelViewMatrix, projectionMatrix, shader);
                    layer.method_23518();
                }
            }
        }

        /**
         * @return All additional render layers this render type should render
         */
        public List<class_1921> getLayers() {
            return this.layers;
        }
    }

    /**
     * Wraps a Veil dynamic render type with a static render type. Useful for {@link net.neoforged.neoforge.client.event.RegisterNamedRenderTypesEvent} or {@link VeilRegisterFixedBuffersEvent}.
     *
     * @since 2.0.0
     */
    public static class RenderTypeWrapper extends class_1921 {

        private static final Object[] NO_PARAMS = new Object[0];

        private final class_2960 id;
        private Object[] params;

        private RenderTypeWrapper(class_2960 id) {
            super(id.toString(), class_290.field_1592, class_293.class_5596.field_27382, 0, false, false, () -> {
            }, () -> {
            });
            this.id = id;
            this.params = NO_PARAMS;
        }

        @Override
        public void method_23516() {
            class_1921 renderType = this.get();
            if (renderType != null) {
                renderType.method_23516();
            }
        }

        @Override
        public void method_23518() {
            class_1921 renderType = this.get();
            if (renderType != null) {
                renderType.method_23518();
            }
        }

        @Override
        public void method_60895(@NotNull class_9801 meshData) {
            class_1921 renderType = this.get();
            if (renderType != null) {
                renderType.method_60895(meshData);
            }
        }

        @Override
        public int method_22722() {
            class_1921 renderType = this.get();
            return renderType != null ? renderType.method_22722() : field_32775;
        }

        @Override
        public @NotNull class_293 method_23031() {
            class_1921 renderType = this.get();
            return renderType != null ? renderType.method_23031() : class_290.field_1592;
        }

        @Override
        public class_293.@NotNull class_5596 method_23033() {
            class_1921 renderType = this.get();
            return renderType != null ? renderType.method_23033() : class_293.class_5596.field_27382;
        }

        @Override
        public @NotNull Optional<class_1921> method_23289() {
            class_1921 renderType = this.get();
            return renderType != null ? renderType.method_23289() : Optional.empty();
        }

        @Override
        public boolean method_24295() {
            class_1921 renderType = this.get();
            return renderType != null && renderType.method_24295();
        }

        @Override
        public boolean method_23037() {
            class_1921 renderType = this.get();
            return renderType != null && renderType.method_23037();
        }

        @Override
        public boolean method_43332() {
            class_1921 renderType = this.get();
            return renderType != null && renderType.method_43332();
        }

        @Override
        public boolean method_60894() {
            class_1921 renderType = this.get();
            return renderType != null && renderType.method_60894();
        }

        /**
         * Sets the parameters to pass to the render type.
         *
         * @param params The new parameters
         */
        public void setParams(Object... params) {
            if (params.length == 0) {
                this.params = NO_PARAMS;
            } else if (this.params.length == params.length) {
                System.arraycopy(params, 0, this.params, 0, params.length);
            } else {
                this.params = Arrays.copyOf(params, params.length);
            }
        }

        /**
         * @return The dynamic render type instance or <code>null</code> if it failed to load
         */
        public @Nullable class_1921 get() {
            return VeilRenderSystem.renderer().getDynamicRenderTypeManager().get(this.id, this.params);
        }
    }
}
