package foundry.veil.impl.client.imgui;

import org.jetbrains.annotations.ApiStatus;

import java.util.function.ObjIntConsumer;
import net.minecraft.class_2960;

@ApiStatus.Internal
public class InactiveVeilImGuiImpl implements VeilImGui {

    @Override
    public void start() {
    }

    @Override
    public void stop() {
    }

    @Override
    public void beginFrame() {
    }

    @Override
    public void endFrame() {
    }

    @Override
    public void toggle() {
    }

    @Override
    public void updateFonts() {
    }

    @Override
    public void addImguiShaders(ObjIntConsumer<class_2960> registry) {
    }
}
