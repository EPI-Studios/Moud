package foundry.veil.api.quasar.emitters.shape;

import com.mojang.serialization.Codec;
import foundry.veil.api.quasar.registry.EmitterShapeRegistry;
import foundry.veil.api.util.CodecUtil;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3fc;

public interface EmitterShape {

    Vector3d getPoint(class_5819 randomSource, Vector3fc dimensions, Vector3fc rotation, Vector3dc position, boolean fromSurface);

    void renderShape(class_4587 stack, class_4588 consumer, Vector3fc dimensions, Vector3fc rotation);

    Codec<EmitterShape> CODEC = CodecUtil.registryOrLegacyCodec(EmitterShapeRegistry.REGISTRY);
}
