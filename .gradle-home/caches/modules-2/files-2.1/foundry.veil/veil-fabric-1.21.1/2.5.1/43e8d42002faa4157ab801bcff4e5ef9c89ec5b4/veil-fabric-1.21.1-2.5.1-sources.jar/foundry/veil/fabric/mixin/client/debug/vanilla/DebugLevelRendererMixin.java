package foundry.veil.fabric.mixin.client.debug.vanilla;

import com.llamalad7.mixinextras.sugar.Local;
import foundry.veil.api.client.render.rendertype.VeilRenderType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.function.Supplier;
import net.minecraft.class_1921;
import net.minecraft.class_3695;
import net.minecraft.class_761;

@Mixin(class_761.class)
public abstract class DebugLevelRendererMixin {

    @Redirect(method = "renderSectionLayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/util/function/Supplier;)V"))
    private void fixBlockProfilerName(class_3695 instance, Supplier<String> stringSupplier, @Local(argsOnly = true) class_1921 renderType) {
        instance.method_15405("render_" + VeilRenderType.getName(renderType));
    }
}
