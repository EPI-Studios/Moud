package foundry.veil.fabric.network;

import foundry.veil.api.network.handler.ServerPacketContext;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_3222;
import net.minecraft.class_7648;
import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public record FabricServerPacketContext(ServerPlayNetworking.Context context) implements ServerPacketContext {

    @Override
    public @NotNull class_3222 player() {
        return this.context.player();
    }

    @Override
    public class_2596<?> createPacket(class_8710 payload) {
        return this.context.responseSender().createPacket(payload);
    }

    @Override
    public void sendPacket(class_2596<?> packet, @Nullable class_7648 callback) {
        this.context.responseSender().sendPacket(packet, callback);
    }

    @Override
    public void disconnect(class_2561 disconnectReason) {
        this.context.responseSender().disconnect(disconnectReason);
    }
}
