package foundry.veil.fabric.mixin.client;

import foundry.veil.VeilClient;
import foundry.veil.impl.client.imgui.VeilImGuiImpl;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static org.lwjgl.glfw.GLFW.GLFW_PRESS;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {

    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "keyPress", at = @At("TAIL"))
    public void keyPress(long window, int key, int scancode, int action, int mods, CallbackInfo ci) {
        if (window == this.minecraft.method_22683().method_4490() && action == GLFW_PRESS && VeilClient.EDITOR_KEY.method_1417(key, scancode)) {
            VeilImGuiImpl.get().toggle();
        }
    }
}
