package foundry.veil.api.quasar.data.module.update;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import foundry.veil.api.quasar.data.ParticleModuleTypeRegistry;
import foundry.veil.api.quasar.data.module.ModuleType;
import foundry.veil.api.quasar.data.module.ParticleModuleData;
import foundry.veil.api.quasar.emitters.module.update.TickSubEmitterModule;
import foundry.veil.api.quasar.particle.ParticleModuleSet;
import net.minecraft.class_2960;

public record TickSubEmitterModuleData(class_2960 subEmitter, int frequency) implements ParticleModuleData {

    public static final MapCodec<TickSubEmitterModuleData> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_2960.field_25139.fieldOf("subemitter").forGetter(TickSubEmitterModuleData::subEmitter),
            Codec.INT.fieldOf("frequency").forGetter(TickSubEmitterModuleData::frequency)
    ).apply(instance, TickSubEmitterModuleData::new));

    @Override
    public void addModules(ParticleModuleSet.Builder builder) {
        builder.addModule(new TickSubEmitterModule(this));
    }

    @Override
    public ModuleType<?> getType() {
        return ParticleModuleTypeRegistry.TICK_SUB_EMITTER;
    }
}
