package foundry.veil.api.client.render.texture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_3300;

/**
 * Allows a texture to hook into the preloading logic.
 */
public interface VeilPreloadedTexture {

    CompletableFuture<?> preload(class_3300 resourceManager, Executor backgroundExecutor);
}
