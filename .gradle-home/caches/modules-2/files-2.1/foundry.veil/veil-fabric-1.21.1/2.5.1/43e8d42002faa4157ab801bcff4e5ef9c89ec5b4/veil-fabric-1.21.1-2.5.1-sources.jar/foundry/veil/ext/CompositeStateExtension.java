package foundry.veil.ext;

import org.jetbrains.annotations.ApiStatus;

import java.util.Collection;
import net.minecraft.class_4668;

@ApiStatus.Internal
public interface CompositeStateExtension {

    void veil$addShards(Collection<class_4668> shards);
}
