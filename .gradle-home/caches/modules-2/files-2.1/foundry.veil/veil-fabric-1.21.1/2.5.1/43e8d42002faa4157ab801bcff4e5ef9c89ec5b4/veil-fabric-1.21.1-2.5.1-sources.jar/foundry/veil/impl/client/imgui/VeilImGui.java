package foundry.veil.impl.client.imgui;

import org.jetbrains.annotations.ApiStatus;

import java.util.function.ObjIntConsumer;
import net.minecraft.class_2960;

/**
 * Manages the internal ImGui state.
 *
 * @author Ocelot
 */
@ApiStatus.Internal
public interface VeilImGui {

    void start();

    void stop();

    void beginFrame();

    void endFrame();

    void toggle();

    void updateFonts();

    void addImguiShaders(ObjIntConsumer<class_2960> registry);
}
