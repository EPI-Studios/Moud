package foundry.veil.api.flare.data.model;

import com.mojang.serialization.Codec;
import java.util.Map;
import net.minecraft.class_2350;
import net.minecraft.class_3542;

/**
 * @since 2.5.0
 */
public record ShellElementFace(ShellFaceUV uv) {

    public static final Codec<ShellElementFace> CODEC = ShellFaceUV.CODEC.xmap(ShellElementFace::new, ShellElementFace::uv);
    public static final Codec<Map<class_2350, ShellElementFace>> FULL_CODEC = Codec.simpleMap(class_2350.field_29502, CODEC, class_3542.method_28142(class_2350.values())).codec();

}
