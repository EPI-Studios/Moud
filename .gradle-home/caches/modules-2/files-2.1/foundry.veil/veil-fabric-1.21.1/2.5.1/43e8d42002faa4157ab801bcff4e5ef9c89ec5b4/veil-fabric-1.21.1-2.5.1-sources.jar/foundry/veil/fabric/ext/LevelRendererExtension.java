package foundry.veil.fabric.ext;

import net.minecraft.class_1921;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix4fc;

@ApiStatus.Internal
public interface LevelRendererExtension {

    void veil$renderStage(class_1921 layer, Matrix4fc frustumMatrix, Matrix4fc projection);
}
