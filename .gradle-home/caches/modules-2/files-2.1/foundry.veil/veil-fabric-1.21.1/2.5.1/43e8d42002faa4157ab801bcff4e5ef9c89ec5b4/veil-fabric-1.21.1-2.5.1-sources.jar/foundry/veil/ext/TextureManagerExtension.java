package foundry.veil.ext;

import foundry.veil.api.client.render.texture.VeilPreloadedTexture;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_1044;
import net.minecraft.class_2960;

public interface TextureManagerExtension {

    <T extends class_1044 & VeilPreloadedTexture> CompletableFuture<?> veil$registerPreloadedTexture(class_2960 path, T texture, Executor executor);
}
