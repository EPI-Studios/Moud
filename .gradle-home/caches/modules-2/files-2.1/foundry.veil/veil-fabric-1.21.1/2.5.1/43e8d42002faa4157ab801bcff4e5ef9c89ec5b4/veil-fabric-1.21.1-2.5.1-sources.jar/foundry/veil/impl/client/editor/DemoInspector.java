package foundry.veil.impl.client.editor;

import foundry.veil.api.client.editor.Inspector;
import foundry.veil.api.client.render.VeilRenderSystem;
import imgui.ImGui;
import imgui.type.ImBoolean;
import net.minecraft.class_2561;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class DemoInspector implements Inspector {

    public static final class_2561 TITLE = class_2561.method_43471("inspector.veil.example.imgui.title");

    private final ImBoolean open = new ImBoolean();

    @Override
    public void render() {
        ImGui.showDemoWindow(this.open);

        if (!this.open.get()) {
            VeilRenderSystem.renderer().getEditorManager().hide(this);
        }
    }

    @Override
    public void onShow() {
        this.open.set(true);
    }

    @Override
    public class_2561 getDisplayName() {
        return TITLE;
    }

    @Override
    public class_2561 getGroup() {
        return EXAMPLE_GROUP;
    }
}
