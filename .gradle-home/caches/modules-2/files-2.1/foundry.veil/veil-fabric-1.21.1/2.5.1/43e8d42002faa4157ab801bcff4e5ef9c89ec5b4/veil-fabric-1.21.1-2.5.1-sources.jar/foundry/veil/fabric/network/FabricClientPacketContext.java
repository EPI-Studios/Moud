package foundry.veil.fabric.network;

import foundry.veil.api.network.handler.ClientPacketContext;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_7648;
import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public record FabricClientPacketContext(ClientPlayNetworking.Context context) implements ClientPacketContext {

    @Override
    public class_310 client() {
        return this.context.client();
    }

    @Override
    public class_746 player() {
        return this.context.player();
    }

    @Override
    public class_2596<?> createPacket(class_8710 payload) {
        return this.context.responseSender().createPacket(payload);
    }

    @Override
    public void sendPacket(class_2596<?> packet, @Nullable class_7648 callback) {
        this.context.responseSender().sendPacket(packet, callback);
    }

    @Override
    public void disconnect(class_2561 disconnectReason) {
        this.context.responseSender().disconnect(disconnectReason);
    }
}
