package foundry.veil.api.quasar.emitters;

import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_630;
import net.minecraft.class_761;

public class AnchorPoint {
    public static AnchorPoint TEST_POINT = new AnchorPoint(class_2960.method_60655("quasar", "test_point"));
    private final class_2960 id;
    public Vector3f localOffset = new Vector3f(0, 0, 0);
    public Vector3f worldOffset = new Vector3f(0, 0, 0);
    public List<class_630> modelParts = null;
    public Vector3f origin = new Vector3f(0, 0, 0);
    public Vector4f transformMatrix = new Vector4f();

    public AnchorPoint(class_2960 id) {
        this.id = id;
    }

    public class_2960 getId() {
        return id;
    }

    public Vector3f getLocalOffset() {
        return localOffset;
    }

    public class_243 getWorldOffset(class_1297 entity) {
        if (entity == null) {
            return class_243.field_1353;
        }
        class_243 pos = entity.method_19538();
        pos = pos.method_1031(transformMatrix.x(), transformMatrix.y(), transformMatrix.z());
        return pos;
    }

    public void updatePosition(class_1297 entity) {
        if (this.modelParts == null) {
            return;
        }
        class_4587 stack = new class_4587();
        stack.method_22905(1f, -1f, -1f);
        stack.method_46416(0, -1.501F, 0);
        for (class_630 modelPart : modelParts) {
            modelPart.method_22703(stack);
        }
        Vector4f offset = new Vector4f(localOffset.x(), localOffset.y(), localOffset.z(), 1);
//        stack.mulPose(Vector3f.YP.rotationDegrees(entity.getYRot()));
        offset = stack.method_23760().method_23761().transform(offset);
        transformMatrix = offset;
    }

    public void render(class_4587 stack, class_4597 source, float scalar) {
        stack.method_22903();
        stack.method_46416(transformMatrix.x(), transformMatrix.y(), transformMatrix.z());
        class_4588 consumer = source.getBuffer(class_1921.method_23594());
        stack.method_22905(1 / 16f, 1 / 16f, 1 / 16f);
        class_761.method_22982(stack, consumer, new class_238(-0.5, -0.5, -0.5, 0.5, 0.5, 0.5), 1, 1, 1, 1);
        stack.method_22909();
    }
}
