package foundry.veil.ext;

import org.jetbrains.annotations.ApiStatus;

import java.util.Collection;
import net.minecraft.class_2960;

@ApiStatus.Internal
public interface ShaderInstanceExtension {

    boolean veil$swapBuffers(int activeBuffers);

    void veil$recompile(boolean vertex, String source, int activeBuffers);

    Collection<class_2960> veil$getShaderSources();

    int veil$getActiveBuffers();
}
