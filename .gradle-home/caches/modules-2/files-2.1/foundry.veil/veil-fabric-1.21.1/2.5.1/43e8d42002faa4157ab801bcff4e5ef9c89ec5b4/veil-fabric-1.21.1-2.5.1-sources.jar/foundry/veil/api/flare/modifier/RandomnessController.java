package foundry.veil.api.flare.modifier;

import net.minecraft.class_5819;

/**
 * Controller with a random value each time {@link Controller#getValue()} is called.
 *
 * @author GuyApooye
 * @since 2.5.0
 */
public class RandomnessController extends GlobalController {

    public static final RandomnessController INSTANCE = new RandomnessController("random");

    private final class_5819 randomSource = class_5819.method_43049(10840L);

    private RandomnessController(String name) {
        super(name);
    }

    @Override
    protected float getUpdatedValue() {
        return this.value;
    }

    @Override
    public float getValue() {
        return this.value = this.randomSource.method_43057();
    }
}
