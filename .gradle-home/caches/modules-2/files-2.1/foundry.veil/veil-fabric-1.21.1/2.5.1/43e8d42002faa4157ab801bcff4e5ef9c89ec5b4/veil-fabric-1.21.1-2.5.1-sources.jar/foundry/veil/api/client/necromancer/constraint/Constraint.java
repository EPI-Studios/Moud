package foundry.veil.api.client.necromancer.constraint;

import foundry.veil.api.client.necromancer.Skeleton;
import foundry.veil.api.client.necromancer.SkeletonParent;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public interface Constraint {

    void apply();

    default void renderDebugInfo(Skeleton skeleton, SkeletonParent<?, ?> parent, float pPartialTicks, class_4587 poseStack, class_4597 pBuffer) {
    }
}
