package foundry.veil.api.client.render.rendertype;

import net.minecraft.class_1921;
import net.minecraft.class_4668;

/**
 * Extended render type builder that adds support for custom layers.
 */
public interface VeilRenderTypeBuilder {

    VeilRenderTypeBuilder textureState(class_4668.class_5939 state);

    VeilRenderTypeBuilder shaderState(class_4668.class_5942 state);

    VeilRenderTypeBuilder transparencyState(class_4668.class_4685 state);

    VeilRenderTypeBuilder depthTestState(class_4668.class_4672 state);

    VeilRenderTypeBuilder cullState(class_4668.class_4671 state);

    VeilRenderTypeBuilder lightmapState(class_4668.class_4676 state);

    VeilRenderTypeBuilder overlayState(class_4668.class_4679 state);

    VeilRenderTypeBuilder layeringState(class_4668.class_4675 state);

    VeilRenderTypeBuilder outputState(class_4668.class_4678 state);

    VeilRenderTypeBuilder texturingState(class_4668.class_4684 state);

    VeilRenderTypeBuilder writeMaskState(class_4668.class_4686 state);

    VeilRenderTypeBuilder lineState(class_4668.class_4677 state);

    VeilRenderTypeBuilder colorLogicState(class_4668.class_8559 state);

    VeilRenderTypeBuilder addLayer(class_4668 shard);

    default class_1921.class_4688 create(boolean affectsOutline) {
        return this.create(affectsOutline ? class_1921.class_4750.field_21855 : class_1921.class_4750.field_21853);
    }

    class_1921.class_4688 create(class_1921.class_4750 outlineProperty);
}
