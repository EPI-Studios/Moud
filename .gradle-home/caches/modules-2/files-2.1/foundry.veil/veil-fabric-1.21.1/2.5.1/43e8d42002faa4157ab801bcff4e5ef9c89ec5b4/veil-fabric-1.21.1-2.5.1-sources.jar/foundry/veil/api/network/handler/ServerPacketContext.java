package foundry.veil.api.network.handler;

import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

/**
 * Context for server-side packet handling.
 *
 * @author Ocelot
 */
public interface ServerPacketContext extends PacketContext {

    /**
     * @return The Minecraft server instance
     */
    default MinecraftServer server() {
        return this.player().method_5682();
    }

    @Override
    @NotNull
    class_3222 player();

    @Override
    default @NotNull class_1937 level() {
        return this.player().method_37908();
    }
}
