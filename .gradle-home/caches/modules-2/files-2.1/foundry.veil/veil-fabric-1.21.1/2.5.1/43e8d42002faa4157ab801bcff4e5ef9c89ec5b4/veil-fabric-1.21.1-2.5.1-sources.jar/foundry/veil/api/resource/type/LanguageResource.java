package foundry.veil.api.resource.type;

import foundry.veil.api.resource.VeilResourceAction;
import foundry.veil.api.resource.VeilResourceInfo;
import foundry.veil.api.resource.VeilResourceManager;
import foundry.veil.impl.resource.action.TextEditAction;
import imgui.extension.texteditor.TextEditorLanguageDefinition;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.List;
import net.minecraft.class_1076;
import net.minecraft.class_310;
import net.minecraft.class_3300;

@ApiStatus.Internal
public record LanguageResource(VeilResourceInfo resourceInfo) implements VeilTextResource<LanguageResource> {

    @Override
    public List<VeilResourceAction<LanguageResource>> getActions() {
        return List.of(new TextEditAction<>());
    }

    @Override
    public boolean canHotReload() {
        return true;
    }

    @Override
    public void hotReload(VeilResourceManager resourceManager) throws IOException {
        class_3300 resources = resourceManager.resources(this.resourceInfo);
        class_310 client = class_310.method_1551();
        class_1076 langManager = client.method_1526();

        langManager.method_14491(resources);
    }

    @Override
    public int getIconCode() {
        return 0xEDCF;
    }

    @Override
    public @Nullable TextEditorLanguageDefinition languageDefinition() {
        return null;
    }

}
