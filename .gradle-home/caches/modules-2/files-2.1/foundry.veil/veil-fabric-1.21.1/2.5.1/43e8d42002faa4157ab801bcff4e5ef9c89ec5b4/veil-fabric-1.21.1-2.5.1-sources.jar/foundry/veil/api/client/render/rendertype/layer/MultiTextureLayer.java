package foundry.veil.api.client.render.rendertype.layer;

import com.mojang.serialization.MapCodec;
import foundry.veil.api.client.registry.RenderTypeLayerRegistry;
import foundry.veil.api.client.render.rendertype.VeilRenderTypeBuilder;
import java.util.Arrays;
import net.minecraft.class_4668;

public record MultiTextureLayer(TextureLayer[] textures) implements RenderTypeLayer {

    public static final MapCodec<MultiTextureLayer> CODEC = TextureLayer.CODEC.codec()
            .listOf(2, 12)
            .fieldOf("textures")
            .xmap(textures -> new MultiTextureLayer(textures.toArray(TextureLayer[]::new)),
                    layer -> Arrays.asList(layer.textures));

    @Override
    public void addShard(VeilRenderTypeBuilder builder, Object... params) {
        class_4668.class_5940.class_5941 textureBuilder = class_4668.class_5940.method_34560();
        for (TextureLayer texture : this.textures) {
            textureBuilder.method_34563(texture.texture().parse(params), texture.blur(), texture.mipmap());
        }
        builder.textureState(textureBuilder.method_34562());
    }

    @Override
    public RenderTypeLayerRegistry.LayerType<?> getType() {
        return RenderTypeLayerRegistry.MULTI_TEXTURE.get();
    }
}
