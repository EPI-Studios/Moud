package foundry.veil.api.quasar.particle;

import foundry.veil.Veil;
import foundry.veil.api.TickTaskScheduler;
import foundry.veil.api.client.render.MatrixStack;
import foundry.veil.api.quasar.data.*;
import foundry.veil.api.quasar.data.module.CodeModule;
import foundry.veil.api.quasar.data.module.ParticleModuleData;
import foundry.veil.api.quasar.emitters.module.update.FaceVelocityModule;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1058;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_765;

/*
 *  TODO:
 *   ✅ REQUIRED EmitterModule that controls lifetime, loop, rate, count, position
 *   ✅ OPTIONAL EmitterSettingsModule that controls randomization, emission area, emission shape, emission direction, emission speed, onEdge, linked entity, live position, etc
 *   OPTIONAL EmitterEntityModule that controls entity-specific settings
 *   OPTIONAL EmitterParticleModule that controls particle-specific settings
 *   OPTIONAL EmitterBlockEntityModule that controls block entity-specific settings
 *   OPTIONAL SubEmitterModule that controls sub-emitters
 *   OPTIONAL OnSpawnAction that can be set to run when a particle is spawned
 *   OPTIONAL OnDeathAction that can be set to run when a particle dies
 *   OPTIONAL OnUpdateAction that can be set to run when a particle is updated
 *   OPTIONAL OnRenderAction that can be set to run when a particle is rendered
 */
public class ParticleEmitter {

    private static final Set<class_6880<ParticleModuleData>> REPORTED_MODULES = new HashSet<>();

    private final ParticleSystemManager particleManager;
    private final class_638 level;
    private final ParticleEmitterData emitterData;
    private final List<ParticleModuleData> modules;
    private final class_5819 randomSource;
    private final Vector3d position;
    private final Vector3d offset;
    private final List<QuasarParticle> particles;

    private int maxLifetime;
    private boolean loop;
    private int rate;
    private int count;
    private int maxParticles;
    private List<EmitterShapeSettings> emitterShapeSettings;
    private ParticleSettings particleSettings;
    private boolean forceSpawn;
    private QuasarParticleData particleData;

    @Nullable
    private class_1297 attachedEntity;
    private CompletableFuture<?> spawnTask;
    private CompletableFuture<?> removeTask;
    private boolean removed;

    ParticleEmitter(ParticleSystemManager particleManager, class_638 level, ParticleEmitterData data) {
        this.particleManager = particleManager;
        this.level = level;
        this.emitterData = data;
        this.modules = createModuleSet(data.particleData());
        this.randomSource = class_5819.method_43047();
        this.position = new Vector3d();
        this.offset = new Vector3d();
        this.particles = new LinkedList<>();

        this.maxLifetime = data.maxLifetime();
        this.loop = data.loop();
        this.rate = data.rate();
        this.count = data.count();
        this.maxParticles = data.maxParticles();
        EmitterSettings emitterSettings = data.emitterSettings();
        this.emitterShapeSettings = emitterSettings.emitterShapeSettings();
        this.particleSettings = emitterSettings.particleSettings();
        this.forceSpawn = emitterSettings.forceSpawn();
        this.particleData = data.particleData();

        // Perform the removal task first so no more particles are spawned
        this.reset();
        TickTaskScheduler scheduler = particleManager.getScheduler();
        this.spawnTask = scheduler.scheduleAtFixedRate(this::spawn, 1, data.rate()).toCompletableFuture();
    }

    @ApiStatus.Internal
    void onAdd() {
        this.spawn();
    }

    @ApiStatus.Internal
    public static void clearErrors() {
        REPORTED_MODULES.clear();
    }

    private void spawn() {
        int count = Math.min(this.maxParticles, this.count);
        this.particleManager.reserve(count);

        for (int i = 0; i < count; i++) {
            Vector3dc particlePos = this.emitterShapeSettings.get(i % this.emitterShapeSettings.size()).getPos(this.randomSource, this.position);
            Vector3fc particleDirection = this.particleSettings.particleDirection(this.randomSource);

            // TODO
//        this.getParticleData().getInitModules().stream().filter(force -> force instanceof InitialVelocityForce).forEach(f -> {
//            InitialVelocityForce force = (InitialVelocityForce) f;
//            if (force.takesParentRotation()) {
//                Vector3fc rotation = emitterSettings.emitterShapeSettings().value().getRotation();
//                force.velocityDirection = force.velocityDirection
//                        .xRot((float) -Math.toRadians(rotation.x()))
//                        .yRot((float) -Math.toRadians(rotation.y()))
//                        .zRot((float) -Math.toRadians(rotation.z()));
//            }
//        });

            ParticleModuleSet.Builder builder = ParticleModuleSet.builder();
            for (ParticleModuleData module : this.modules) {
                module.addModules(builder);
            }
            if (this.particleData.faceVelocity()) {
                builder.addModule(new FaceVelocityModule());
            }

            QuasarParticle particle = new QuasarParticle(this.level, this.randomSource, this.particleManager.getScheduler(), this.particleData, builder.build(), this.particleSettings, this);
            particle.getPosition().set(particlePos);
            particle.getVelocity().set(particleDirection);
            particle.init();
            this.particles.add(particle);
        }
    }

    private static List<ParticleModuleData> createModuleSet(QuasarParticleData data) {
        List<class_6880<ParticleModuleData>> allModules = data.getAllModules();
        ArrayList<ParticleModuleData> list = new ArrayList<>(allModules.size());
        for (class_6880<ParticleModuleData> module : allModules) {
            if (!module.method_40227()) {
                if (REPORTED_MODULES.add(module)) {
                    Veil.LOGGER.error("Unknown module: {}", (module instanceof class_6880.class_6883<ParticleModuleData> ref ? ref.method_40237().method_29177() : module.getClass().getName()));
                }
                continue;
            }
            list.add(module.comp_349());
        }
        list.trimToSize();
        return list;
    }

    private void expire() {
        if (this.loop) {
            this.reset();
        } else {
            this.remove();
        }
    }

    private void cancelTasks() {
        if (this.spawnTask != null) {
            this.spawnTask.cancel(false);
            this.spawnTask = null;
        }
        if (this.removeTask != null) {
            this.removeTask.cancel(false);
            this.removeTask = null;
        }
    }

    @ApiStatus.Internal
    void tick() {
        this.position.set(0);
        if (this.attachedEntity != null) {
            if (this.attachedEntity.method_5805()) {
                class_243 pos = this.attachedEntity.method_19538();
                this.position.set(pos.field_1352, pos.field_1351, pos.field_1350);
            } else {
                this.attachedEntity = null;
                this.remove();
            }
        }

        this.position.add(this.offset);
        Iterator<QuasarParticle> iterator = this.particles.iterator();
        while (iterator.hasNext()) {
            QuasarParticle particle = iterator.next();
            particle.tick();

            if (particle.isRemoved()) {
                iterator.remove();
                particle.onRemove();
            }
        }

//        if (this.removed) {
//            this.cancelTasks();
//        } else {
//            // Let particles finish before removing the emitter
//            if (this.age > this.emitterData.maxLifetime()) {
//                if (this.emitterData.loop()) {
//                    this.reset();
//                } else {
//                    this.remove();
//                }
//            }
//        }
    }

    // TODO move to renderer
    @ApiStatus.Internal
    public void render(MatrixStack matrixStack, class_4597 bufferSource, class_4184 camera, float partialTicks) {
        if (this.particles.isEmpty()) {
            return;
        }

        RenderStyle renderStyle = this.particleData.renderStyle();
        if (!renderStyle.setup(this.particles.size())) {
            return;
        }

        class_243 projectedView = camera.method_19326();
        Vector3f renderOffset = new Vector3f();
        class_1921 lastRenderType = null;
        class_4588 builder = null;

        for (QuasarParticle particle : this.particles) {
            RenderData renderData = particle.getRenderData();

            particle.render(partialTicks);

            renderData.renderTrails(matrixStack, bufferSource, projectedView, class_765.field_32767);

            Vector3dc renderPosition = renderData.getRenderPosition();
            renderOffset.set(
                    (float) (renderPosition.x() - projectedView.method_10216()),
                    (float) (renderPosition.y() - projectedView.method_10214()),
                    (float) (renderPosition.z() - projectedView.method_10215()));

            class_1921 renderType = renderData.getRenderType();
            if (!renderType.equals(lastRenderType)) {
                lastRenderType = renderType;
                builder = bufferSource.getBuffer(renderType);

                class_1058 sprite = renderData.getAtlasSprite();
                if (sprite != null) {
                    builder = sprite.method_24108(builder);
                }
            }

            renderStyle.render(matrixStack, particle, renderData, renderOffset, builder, 1, partialTicks);
        }
        renderStyle.clear();
    }

    @ApiStatus.Internal
    void onRemoved() {
        this.cancelTasks();
        Iterator<QuasarParticle> iterator = this.particles.iterator();
        while (iterator.hasNext()) {
            iterator.next().onRemove();
            iterator.remove();
        }
    }

    /**
     * <p>Adds a custom module with user code that is added to all particles spawned after this is called.</p>
     * <p>The module cannot be serialized and does not affect the state of any other emitters.</p>
     *
     * @param module The module to add
     */
    public void addCodeModule(CodeModule module) {
        this.modules.add(module);
    }

    /**
     * Attempts to remove the oldest specified number of particles.
     *
     * @param count The number of particles to attempt to remove
     * @return The number of particles removed
     */
    public int trim(int count) {
        // Don't allow high-priority particles to be trimmed
        if (this.forceSpawn) {
            return 0;
        }

        int removeCount;
        Iterator<QuasarParticle> iterator = this.particles.iterator();
        for (removeCount = 0; iterator.hasNext() && removeCount < count; removeCount++) {
            iterator.remove();
        }
        return removeCount;
    }

    /**
     * Marks this emitter to be removed next tick.
     */
    public void remove() {
        this.removed = true;
        this.cancelTasks();
    }

    /**
     * Resets the emitter to its initial state
     */
    public void reset() {
        this.removed = false;
        if (this.removeTask != null) {
            this.removeTask.cancel(false);
        }
        this.removeTask = this.particleManager.getScheduler().schedule(this::expire, this.maxLifetime).toCompletableFuture();
    }

    public @Nullable class_2960 getRegistryName() {
        return this.emitterData.getRegistryId();
    }

    /**
     * Whether the emitter has completed its lifetime
     */
    public boolean isRemoved() {
        return this.removed && this.particles.isEmpty();
    }

    /**
     * Position of the emitter
     */
    public Vector3d getPosition() {
        return this.position;
    }

    public ParticleEmitterData getData() {
        return this.emitterData;
    }

    public int getParticleCount() {
        return this.particles.size();
    }

    public int getMaxLifetime() {
        return this.maxLifetime;
    }

    public boolean isLoop() {
        return this.loop;
    }

    public int getRate() {
        return this.rate;
    }

    public int getCount() {
        return this.count;
    }

    public int getMaxParticles() {
        return this.maxParticles;
    }

    public List<EmitterShapeSettings> getEmitterShapeSettings() {
        return this.emitterShapeSettings;
    }

    public ParticleSettings getParticleSettings() {
        return this.particleSettings;
    }

    public boolean isForceSpawn() {
        return this.forceSpawn;
    }

    public QuasarParticleData getParticleData() {
        return this.particleData;
    }

    /**
     * @return The entity this emitter is attached to and will apply
     */
    public @Nullable class_1297 getAttachedEntity() {
        return this.attachedEntity;
    }

    /**
     * Sets the position of the emitter relative to the origin of the world or attached entity.
     *
     * @param position The position
     */
    public void setPosition(class_243 position) {
        this.setPosition(position.field_1352, position.field_1351, position.field_1350);
    }

    /**
     * Sets the position of the emitter relative to the origin of the world or attached entity.
     *
     * @param position The position
     */
    public void setPosition(Vector3dc position) {
        this.setPosition(position.x(), position.y(), position.z());
    }

    /**
     * Sets the position of the emitter relative to the origin of the world or attached entity.
     *
     * @param x The x position
     * @param y The y position
     * @param z The z position
     */
    public void setPosition(double x, double y, double z) {
        this.offset.set(x, y, z);
        if (this.attachedEntity != null) {
            this.position.set(this.attachedEntity.method_23317(), this.attachedEntity.method_23318(), this.attachedEntity.method_23321()).add(this.offset);
        } else {
            this.position.set(this.offset);
        }
    }

    public void setMaxLifetime(int maxLifetime) {
        this.maxLifetime = maxLifetime;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setMaxParticles(int maxParticles) {
        this.maxParticles = maxParticles;
    }

    public void setEmitterShapeSettings(List<EmitterShapeSettings> emitterShapeSettings) {
        this.emitterShapeSettings = emitterShapeSettings;
    }

    public void setParticleSettings(ParticleSettings particleSettings) {
        this.particleSettings = particleSettings;
    }

    public void setForceSpawn(boolean forceSpawn) {
        this.forceSpawn = forceSpawn;
    }

    public void setParticleData(QuasarParticleData particleData) {
        this.particleData = particleData;
    }

    /**
     * Sets the origin of the emitter position to match the specified entity.
     * That means the value set by {@link #setPosition(double, double, double)} will not be interpreted as an offset from the entity position.
     *
     * @param entity The entity to attach to
     */
    public void setAttachedEntity(@Nullable class_1297 entity) {
        this.attachedEntity = entity;
        if (entity != null) {
            this.position.set(entity.method_23317(), entity.method_23318(), entity.method_23321()).add(this.offset);
        } else {
            this.position.set(this.offset);
        }
    }
}
