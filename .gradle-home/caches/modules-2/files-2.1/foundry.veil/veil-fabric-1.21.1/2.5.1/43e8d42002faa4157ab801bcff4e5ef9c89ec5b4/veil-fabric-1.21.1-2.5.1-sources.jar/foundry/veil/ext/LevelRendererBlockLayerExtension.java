package foundry.veil.ext;

import net.minecraft.class_1921;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix4fc;

@ApiStatus.Internal
public interface LevelRendererBlockLayerExtension {

    void veil$drawBlockLayer(class_1921 renderType, double x, double y, double z, Matrix4fc frustum, Matrix4fc projection);
}
