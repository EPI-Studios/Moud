package foundry.veil.api.quasar.emitters.shape;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public class Disc implements EmitterShape {

    @Override
    public Vector3d getPoint(class_5819 randomSource, Vector3fc dimensions, Vector3fc rotation, Vector3dc position, boolean fromSurface) {
        double x = randomSource.method_43059();
        double y = 0.0000001;
        double z = randomSource.method_43059();
        Vector3d normal = new Vector3d(x, y, z).normalize();
        Vector3fc dim = dimensions;
        if (!fromSurface) {
            normal.mul(randomSource.method_43058()).normalize();
            dim = dimensions.mul(
                    randomSource.method_43057(),
                    randomSource.method_43057(),
                    randomSource.method_43057(),
                    new Vector3f()
            );
        }
        Vector3d pos = normal.mul(dim);
        pos = pos.rotateX((float) Math.toRadians(rotation.x())).rotateY((float) Math.toRadians(rotation.y())).rotateZ((float) Math.toRadians(rotation.z()));
        return pos.add(position);
    }

    @Override
    public void renderShape(class_4587 stack, class_4588 consumer, Vector3fc dimensions, Vector3fc rotation) {
        float radius = dimensions.x();
        float angle = 0;
        float angleStep = 360f / 32f;
        float x = (float) 0;
        float y = (float) 0;
        float z = (float) 0;
        for (int i = 0; i < 32; i++) {
            float x1 = (float) (x + Math.cos(Math.toRadians(angle)) * radius);
            float z1 = (float) (z + Math.sin(Math.toRadians(angle)) * radius);
            float x2 = (float) (x + Math.cos(Math.toRadians(angle + angleStep)) * radius);
            float z2 = (float) (z + Math.sin(Math.toRadians(angle + angleStep)) * radius);
            consumer.method_22918(stack.method_23760().method_23761(), x1, y, z1).method_22915(0.15f, 0.15f, 1, 1).method_22914(0, 1, 0);
            angle += angleStep;
        }
    }
}
