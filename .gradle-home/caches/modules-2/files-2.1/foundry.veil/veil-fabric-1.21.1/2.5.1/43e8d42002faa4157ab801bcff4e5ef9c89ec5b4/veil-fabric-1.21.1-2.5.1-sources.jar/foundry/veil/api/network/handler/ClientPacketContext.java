package foundry.veil.api.network.handler;

import net.minecraft.class_310;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;

/**
 * Context for client-side packet handling.
 *
 * @author Ocelot
 */
public interface ClientPacketContext extends PacketContext {

    /**
     * @return The Minecraft client instance
     */
    class_310 client();

    @Override
    @Nullable
    class_746 player();
}
