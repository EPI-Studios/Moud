package foundry.veil.api.quasar.fx;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import foundry.veil.api.client.render.MatrixStack;
import foundry.veil.api.quasar.emitters.module.render.TrailSettings;
import foundry.veil.impl.quasar.MathUtil;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.Locale;
import java.util.function.Function;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_4608;

public class Trail {

    public enum TilingMode {
        NONE,
        STRETCH,
        REPEAT;

        public static final Codec<TilingMode> CODEC = Codec.STRING.flatXmap(name -> {
            for (TilingMode value : TilingMode.values()) {
                if (value.name().equalsIgnoreCase(name)) {
                    return DataResult.success(value);
                }
            }
            return DataResult.error(() -> "Unknown Tiling Mode");
        }, tilingMode1 -> DataResult.success(tilingMode1.name().toLowerCase(Locale.ROOT)));
    }

    private class_243[] points;
    private class_243[] rotations;
    private int color;
    private Function<Float, Float> widthFunction;
    private int length = 100;
    private boolean billboard = false;
    private TilingMode tilingMode = TilingMode.STRETCH;
    private int frequency = 1;
    private float minDistance = 0f;
    private class_2960 texture = null;
    private boolean parentRotation = false;
    private int timeout = 0;

    public Trail(TrailSettings settings) {
        this(MathUtil.colorFromVec4f(settings.getTrailColor()), (ageScale) -> settings.getTrailWidthModifier().modify(ageScale, 1));
        this.billboard = settings.getBillboard();
        this.length = settings.getTrailLength();
        this.frequency = settings.getTrailFrequency();
        this.tilingMode = settings.getTilingMode();
        this.texture = settings.getTrailTexture();
        this.parentRotation = settings.getParentRotation();
    }

    public Trail(class_243[] points, int color, Function<Float, Float> widthFunction) {
        this.points = points;
        this.color = color;
        this.widthFunction = widthFunction;
    }

    public Trail(int color, Function<Float, Float> widthFunction) {
        this(new class_243[]{class_243.field_1353}, color, widthFunction);
    }

    public void setParentRotation(boolean parentRotation) {
        this.parentRotation = parentRotation;
    }

    public void setTilingMode(TilingMode tilingMode) {
        this.tilingMode = tilingMode;
    }

    public void setTexture(class_2960 texture) {
        this.texture = texture;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public void setMinDistance(float minDistance) {
        this.minDistance = minDistance;
    }

    public void setPoints(class_243[] points) {
        if (points.length > this.length) {
            class_243[] newPoints = new class_243[this.length];
            System.arraycopy(points, points.length - this.length, newPoints, 0, this.length);
            points = newPoints;
        }
        this.points = points;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public void setBillboard(boolean billboard) {
        this.billboard = billboard;
    }

    public void setWidthFunction(Function<Float, Float> widthFunction) {
        this.widthFunction = widthFunction;
    }

    public class_2960 getTexture() {
        return this.texture;
    }

    public int getLength() {
        return this.length;
    }

    public void pushPoint(class_243 point) {
        if (this.timeout > class_310.method_1551().method_22683().method_22092() * 5 && this.timeout % 3 == 0) {
            //remove the last point in the array
            class_243[] newPoints = new class_243[this.points.length - 1];
            System.arraycopy(this.points, 1, newPoints, 0, this.points.length - 1);
            this.points = newPoints;
            return;
        }
        if (this.points.length == 0) {
            this.points = new class_243[]{point};
            return;
        }
        if (this.points[this.points.length - 1].method_1022(point) < this.minDistance) {
            this.timeout++;
            return;
        }
        // test if point is same as last point
        if (this.points[this.points.length - 1].equals(point)) {
            this.timeout++;
            return;
        }
        // add point to end of array and remove first point if array is longer than length
        if (this.points[0] == class_243.field_1353) {
            this.points[0] = point;
            return;
        }
        this.timeout = 0;
        class_243[] newPoints = new class_243[this.points.length + 1];
        System.arraycopy(this.points, 0, newPoints, 0, this.points.length);
        newPoints[this.points.length] = point;
        if (newPoints.length > this.length) {
            class_243[] newPoints2 = new class_243[this.length];
            System.arraycopy(newPoints, 1, newPoints2, 0, this.length);
            newPoints = newPoints2;
        }
        this.points = newPoints;
    }

    public void pushRotatedPoint(class_243 point, class_243 rotation) {
        if (this.timeout > class_310.method_1551().method_22683().method_22092() * 5 && this.timeout % 5 == 0 && this.points.length > 0) {
            //remove the last point in the array
            class_243[] newPoints = new class_243[this.points.length - 1];
            System.arraycopy(this.points, 1, newPoints, 0, this.points.length - 1);
            this.points = newPoints;
            class_243[] newRotations = new class_243[this.rotations.length - 1];
            System.arraycopy(this.rotations, 1, newRotations, 0, this.rotations.length - 1);
            this.rotations = newRotations;
            return;
        }
        if (this.points.length == 0) {
            this.points = new class_243[]{point};
            this.rotations = new class_243[]{rotation};
            return;
        }
        if (this.points[0] == class_243.field_1353) {
            this.points[0] = point;
            this.rotations = new class_243[]{rotation};
            return;
        }
        if (this.points[this.points.length - 1].method_1022(point) < this.minDistance) {
            this.timeout++;
            return;
        }
        // test if point is same as last point
        if (this.points.length > 0 && this.points[this.points.length - 1].equals(point)) {
            this.timeout++;
            return;
        }
        if (this.rotations == null) {
            this.rotations = new class_243[]{rotation};
        }
        // add point to end of array and remove first point if array is longer than length
        class_243[] newPoints = new class_243[this.points.length + 1];
        class_243[] newRotations = new class_243[this.points.length + 1];
        System.arraycopy(this.points, 0, newPoints, 0, this.points.length);
        System.arraycopy(this.rotations, 0, newRotations, 0, this.rotations.length);
        newPoints[this.points.length] = point;
        newRotations[this.rotations.length] = rotation;
        if (newPoints.length > this.length) {
            class_243[] newPoints2 = new class_243[this.length];
            class_243[] newRotations2 = new class_243[this.length];
            System.arraycopy(newPoints, 1, newPoints2, 0, this.length);
            System.arraycopy(newRotations, 1, newRotations2, 0, this.length);
            newPoints = newPoints2;
            newRotations = newRotations2;
        }
        this.points = newPoints;
        this.rotations = newRotations;
    }

    public void render(MatrixStack stack, class_4588 consumer, int light) {
        Vector3f[][] corners = new Vector3f[this.points.length][2];
        for (int i = 0; i < this.points.length; i++) {
            if (i % this.frequency != 0) {
                continue;
            }
            float width = this.widthFunction.apply((float) i / (this.points.length - 1));
            Vector3f topOffset = new Vector3f(0, (width / 2f), 0);
            Vector3f bottomOffset = new Vector3f(0, -(width / 2f), 0);
            if (this.billboard) {
                class_243 a = class_310.method_1551().field_1773.method_19418().method_19326().method_1020(this.points[i]).method_1029();
                Vector3f cameraDirection = new Vector3f((float) a.field_1352, (float) a.field_1351, (float) a.field_1350);
                class_243 b = this.points[Math.min(i + this.frequency, this.points.length - 1)].method_1020(this.points[i]).method_1029();
                Vector3f dirToNextPoint = new Vector3f((float) b.method_10216(), (float) b.method_10214(), (float) b.method_10215());
                Vector3f axis = new Vector3f(cameraDirection);
                // invert the axis
                axis.mul(-1);
                axis.cross(dirToNextPoint);
                topOffset = new Vector3f(axis);
                topOffset.mul(width / 2f);
                bottomOffset = new Vector3f(axis);
                bottomOffset.mul(-width / 2f);
            } else if (this.rotations[i] != null && this.parentRotation) {
                class_243 a = this.rotations[Math.min(i + this.frequency, this.rotations.length - 1)];
                Vector3f cameraDirection = new Vector3f((float) a.field_1352, (float) a.field_1351, (float) a.field_1350);
                class_243 b = this.points[Math.min(i + this.frequency, this.points.length - 1)].method_1020(this.points[i]).method_1029();
                Vector3f dirToNextPoint = new Vector3f((float) b.method_10216(), (float) b.method_10214(), (float) b.method_10215());
                Vector3f axis = new Vector3f(cameraDirection);
                // invert the axis
                axis.mul(-1);
                axis.cross(dirToNextPoint);
                topOffset = new Vector3f(axis);
                topOffset.mul(width / 2f);
                bottomOffset = new Vector3f(axis);
                bottomOffset.mul(-width / 2f);
            }
            topOffset.add((float) this.points[i].field_1352, (float) this.points[i].field_1351, (float) this.points[i].field_1350);
            bottomOffset.add((float) this.points[i].field_1352, (float) this.points[i].field_1351, (float) this.points[i].field_1350);
            corners[i / this.frequency][0] = topOffset;
            corners[i / this.frequency][1] = bottomOffset;
        }
        this.renderPoints(stack, consumer, light, corners, this.color);
    }

    private void renderPoints(MatrixStack stack, class_4588 consumer, int light, Vector3f[][] corners, int color) {
        int r = color >> 16 & 255;
        int g = color >> 8 & 255;
        int b = color & 255;
        int a = color >> 24 & 255;
        for (int i = 0; i < corners.length; i++) {
            Vector3f top = corners[i][0];
            Vector3f bottom = corners[i][1];
//            Vector3f nextTop = corners[i + 1][0];
//            Vector3f nextBottom = corners[i + 1][1];
            if (top == null || bottom == null) {
                continue;
            }
            float u = 0;
            if (this.tilingMode == TilingMode.STRETCH) {
                u = (float) i / (corners.length - 1);
            }
            Matrix4f matrix4f = stack.position();
            consumer.method_22918(matrix4f, bottom.x(), bottom.y(), bottom.z()).method_1336(r, g, b, a).method_22913(u, 0).method_22922(class_4608.field_21444).method_60803(light).method_22914(0, 1, 0);
            consumer.method_22918(matrix4f, top.x(), top.y(), top.z()).method_1336(r, g, b, a).method_22913(u, 1).method_22922(class_4608.field_21444).method_60803(light).method_22914(0, 1, 0);
//            consumer.vertex(matrix4f, nextTop.x(), nextTop.y(), nextTop.z()).color(r, g, b, a).uv(u1, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(0, 1, 0).endVertex();
//            consumer.vertex(matrix4f, nextBottom.x(), nextBottom.y(), nextBottom.z()).color(r, g, b, a).uv(u1, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(0, 1, 0).endVertex();
        }
    }
}
