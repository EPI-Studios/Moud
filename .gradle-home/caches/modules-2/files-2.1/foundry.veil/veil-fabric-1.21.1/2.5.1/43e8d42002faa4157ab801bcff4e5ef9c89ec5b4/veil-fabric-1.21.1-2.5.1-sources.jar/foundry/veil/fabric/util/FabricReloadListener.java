package foundry.veil.fabric.util;

import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public record FabricReloadListener(class_2960 id,
                                   class_3302 listener) implements IdentifiableResourceReloadListener {

    @Override
    public class_2960 getFabricId() {
        return this.id;
    }

    @Override
    public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
        return this.listener.method_25931(preparationBarrier, resourceManager, preparationsProfiler, reloadProfiler, backgroundExecutor, gameExecutor);
    }

    @Override
    public int hashCode() {
        return this.listener.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }

        FabricReloadListener that = (FabricReloadListener) o;

        if (!this.id.equals(that.id)) {
            return false;
        }
        return this.listener.equals(that.listener);
    }

    @Override
    public String toString() {
        return this.listener.toString();
    }

    @Override
    public String method_22322() {
        return this.listener.method_22322();
    }
}
