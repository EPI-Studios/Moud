package foundry.veil.ext;

import net.minecraft.class_2960;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface TextureAtlasExtension {

    boolean veil$hasTexture(class_2960 location);
}
